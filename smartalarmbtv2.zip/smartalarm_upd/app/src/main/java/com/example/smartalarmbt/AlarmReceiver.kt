package com.example.smartalarmbt

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {

        val alarmId = intent.getIntExtra("alarm_id", -1)
        val mission = intent.getStringExtra("mission") ?: MissionType.QUIZ.name

        Log.d("AlarmReceiver", "Alarm wywołany — ID=$alarmId (delay 3 sekundy)...")

        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({

            BluetoothManager.notifyAlarmStarted(context)

            val act = Intent(context, MissionActivity::class.java).apply {
                putExtra("alarm_id", alarmId)
                putExtra("mission", mission)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            context.startActivity(act)

        }, 2750)
    }
}
