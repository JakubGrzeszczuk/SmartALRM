package com.example.smartalarmbt

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.random.Random

class SnakeView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var onMissionComplete: (() -> Unit)? = null
    var targetPoints = 5

    private val paintSnake = Paint().apply { color = Color.GREEN }
    private val paintFood = Paint().apply { color = Color.RED }
    private val paintText = Paint().apply {
        color = Color.WHITE
        textSize = 48f
    }

    private var cellSize = 40
    private val cols = 20
    private val rows = 20

    private enum class Direction { UP, DOWN, LEFT, RIGHT }
    private var direction = Direction.RIGHT
    private var nextDirection = Direction.RIGHT

    private val snake = mutableListOf<Pair<Int, Int>>()
    private var food = Pair(5, 5)
    private var score = 0

    private var running = false
    private var loopStarted = false
    private var firstStart = true

    private var lastX = 0f
    private var lastY = 0f

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)

        cellSize = minOf(w / cols, h / rows)

        if (firstStart) {
            firstStart = false
            startGame()
        }
    }

    fun startGame() {
        snake.clear()
        snake.add(Pair(cols / 2, rows / 2))
        direction = Direction.RIGHT
        nextDirection = Direction.RIGHT
        score = 0
        running = true
        spawnFood()
        invalidate()

        if (!loopStarted) {
            loopStarted = true
            startLoop()
        }
    }

    private fun startLoop() {
        postDelayed(object : Runnable {
            override fun run() {
                if (!running) return

                update()
                invalidate()
                postDelayed(this, 150)
            }
        }, 150)
    }

    private fun spawnFood() {
        do {
            food = Pair(Random.nextInt(cols), Random.nextInt(rows))
        } while (snake.contains(food))
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.BLACK)

        for (part in snake) {
            canvas.drawRect(
                part.first * cellSize.toFloat(),
                part.second * cellSize.toFloat(),
                (part.first + 1) * cellSize.toFloat(),
                (part.second + 1) * cellSize.toFloat(),
                paintSnake
            )
        }

        canvas.drawRect(
            food.first * cellSize.toFloat(),
            food.second * cellSize.toFloat(),
            (food.first + 1) * cellSize.toFloat(),
            (food.second + 1) * cellSize.toFloat(),
            paintFood
        )

        canvas.drawText(
            "Zbierz $targetPoints owoców! ($score/$targetPoints)",
            10f, paintText.textSize + 10f, paintText
        )
    }

    private fun update() {
        direction = nextDirection

        val head = snake.first()
        val newHead = when (direction) {
            Direction.UP -> Pair(head.first, head.second - 1)
            Direction.DOWN -> Pair(head.first, head.second + 1)
            Direction.LEFT -> Pair(head.first - 1, head.second)
            Direction.RIGHT -> Pair(head.first + 1, head.second)
        }

        if (newHead.first !in 0 until cols || newHead.second !in 0 until rows) {
            startGame()
            return
        }

        if (snake.contains(newHead)) {
            startGame()
            return
        }

        // ruch
        snake.add(0, newHead)

        if (newHead == food) {
            score++
            if (score >= targetPoints) {
                running = false
                onMissionComplete?.invoke()
                return
            }
            spawnFood()
        } else {
            snake.removeAt(snake.lastIndex)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                lastX = event.x
                lastY = event.y
                performClick()
            }

            MotionEvent.ACTION_UP -> {
                val dx = event.x - lastX
                val dy = event.y - lastY

                if (abs(dx) > abs(dy)) {
                    if (dx > 0 && direction != Direction.LEFT)
                        nextDirection = Direction.RIGHT
                    else if (dx < 0 && direction != Direction.RIGHT)
                        nextDirection = Direction.LEFT
                } else {
                    if (dy > 0 && direction != Direction.UP)
                        nextDirection = Direction.DOWN
                    else if (dy < 0 && direction != Direction.DOWN)
                        nextDirection = Direction.UP
                }
            }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
