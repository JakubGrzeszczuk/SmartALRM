package com.example.smartalarmbt

import java.io.Serializable

enum class MissionType {
    QUIZ, SHAKE, STEPS, SNAKE
}

data class Alarm(
    val id: Int,
    var hour: Int,
    var minute: Int,
    var missionType: MissionType,
    val isActive: Boolean = true
) : Serializable