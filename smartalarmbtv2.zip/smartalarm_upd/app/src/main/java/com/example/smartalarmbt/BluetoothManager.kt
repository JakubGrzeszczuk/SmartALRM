package com.example.smartalarmbt

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import java.io.IOException
import java.util.UUID
import kotlin.concurrent.thread

object BluetoothManager {

    private const val TAG = "BluetoothManager"
    private const val DEVICE_NAME = "HC-05"

    private val SPP_UUID: UUID =
        UUID.fromString("00001101-0000-1000-8000-00805f9b34fb")

    private val _status = MutableLiveData("Rozłączony")
    val status: LiveData<String> = _status

    private val _lastMessage = MutableLiveData("-")
    val lastMessage: LiveData<String> = _lastMessage

    private var socket: BluetoothSocket? = null
    private var readThreadRunning = false
    private var autoReconnect = true
    private var reconnectThreadStarted = false

    @Volatile private var isConnecting = false

    private val REQUIRED_BT_PERMS = arrayOf(
        Manifest.permission.BLUETOOTH_CONNECT,
        Manifest.permission.BLUETOOTH_SCAN
    )

    private var lineBuffer = StringBuilder()

    @Volatile private var lastSentCommand: String? = null

    private fun hasBtPerms(context: Context): Boolean =
        REQUIRED_BT_PERMS.all { perm ->
            ContextCompat.checkSelfPermission(context, perm) ==
                    PackageManager.PERMISSION_GRANTED
        }

    fun connect(context: Context) {

        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null || !adapter.isEnabled) {
            _status.postValue("BT wyłączony lub brak adaptera")
            return
        }

        if (!hasBtPerms(context)) {
            _status.postValue("Brak uprawnień BT")
            return
        }

        if (isConnecting) return
        isConnecting = true

        try { socket?.close() } catch (_: Exception) {}
        socket = null
        readThreadRunning = false

        thread {
            try {
                _status.postValue("Łączenie...")

                val device = findDevice(context, adapter)
                if (device == null) {
                    _status.postValue("Nie znaleziono: $DEVICE_NAME")
                    return@thread
                }

                val tmpSocket = device.createInsecureRfcommSocketToServiceRecord(SPP_UUID)

                try { adapter.cancelDiscovery() } catch (_: Exception) {}

                try {
                    tmpSocket.connect()
                } catch (ex: Exception) {
                    _status.postValue("Błąd połączenia: ${ex.message}")
                    socket = null
                    return@thread
                }

                socket = tmpSocket

                try {
                    val dumpBuf = ByteArray(512)
                    while (tmpSocket.inputStream.available() > 0) {
                        tmpSocket.inputStream.read(dumpBuf)
                    }
                } catch (_: Exception) {}

                synchronized(lineBuffer) { lineBuffer.clear() }

                _status.postValue("Połączono z ${device.name}")

                startReading(context)

            } catch (ex: Exception) {
                _status.postValue("Błąd: ${ex.message}")
                socket = null
            } finally {
                isConnecting = false
            }
        }
    }

    fun startAutoReconnect(context: Context) {
        if (reconnectThreadStarted) return
        reconnectThreadStarted = true

        thread {
            while (autoReconnect) {
                try {
                    val adapter = BluetoothAdapter.getDefaultAdapter()

                    val shouldReconnect =
                        socket == null &&
                                adapter != null &&
                                adapter.isEnabled &&
                                hasBtPerms(context) &&
                                findDevice(context, adapter) != null &&
                                !isConnecting

                    if (shouldReconnect) {
                        _status.postValue("AutoReconnect: próba połączenia…")
                        connect(context)
                    }

                    Thread.sleep(1000)

                } catch (_: Exception) {}
            }
        }
    }

    private fun findDevice(context: Context, adapter: BluetoothAdapter): BluetoothDevice? {
        return try {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED) return null

            adapter.bondedDevices.firstOrNull { it.name == DEVICE_NAME }

        } catch (_: Exception) { null }
    }

    private fun startReading(context: Context) {
        val s = socket ?: return
        if (readThreadRunning) return
        readThreadRunning = true

        thread {
            try {
                val buffer = ByteArray(1024)
                val input = s.inputStream

                while (true) {
                    val bytes = input.read(buffer)
                    if (bytes > 0) {
                        val chunk = String(buffer, 0, bytes)

                        synchronized(lineBuffer) {
                            for (c in chunk) {
                                if (c == '\n' || c == '\r') {
                                    if (lineBuffer.isNotEmpty()) {
                                        val line = lineBuffer.toString()
                                        lineBuffer.clear()

                                        val cleaned = line.trim()
                                        if (cleaned.isEmpty()) continue

                                        if (!cleaned.startsWith("OK") && !cleaned.startsWith("ERR")) {
                                            continue
                                        }

                                        _lastMessage.postValue(cleaned)
                                    }
                                } else {
                                    lineBuffer.append(c)
                                }
                            }
                        }
                    }
                }

            } catch (ex: Exception) {
                Log.e(TAG, "Połączenie przerwane: ${ex.message}")
                close()
                socket = null

            } finally {
                readThreadRunning = false
            }
        }
    }

    fun sendCommand(context: Context, cmd: String) {
        val s = socket ?: return

        thread {
            try {
                if (!hasBtPerms(context)) {
                    _status.postValue("Brak uprawnień BT")
                    return@thread
                }

                synchronized(lineBuffer) { lineBuffer.clear() }
                lastSentCommand = cmd

                s.outputStream.write((cmd + "\n").toByteArray())
                s.outputStream.flush()

            } catch (_: IOException) {
                _status.postValue("Błąd wysyłania")
            }
        }
    }

    fun syncTimeWithMcu(context: Context) {
        val now = java.util.Calendar.getInstance()

        val y = now.get(java.util.Calendar.YEAR)
        val m = now.get(java.util.Calendar.MONTH) + 1
        val d = now.get(java.util.Calendar.DAY_OF_MONTH)
        val h = now.get(java.util.Calendar.HOUR_OF_DAY)
        val min = now.get(java.util.Calendar.MINUTE)
        val s = now.get(java.util.Calendar.SECOND)

        synchronized(lineBuffer) { lineBuffer.clear() }

        sendCommand(context, "DATE %04d-%02d-%02d".format(y, m, d))
        Thread.sleep(250)
        sendCommand(context, "SET %02d:%02d:%02d".format(h, min, s))
    }

    fun notifyAlarmStarted(context: Context) =
        sendCommand(context, "ALARM:ON")

    fun notifyMissionCompleted(context: Context) =
        sendCommand(context, "MIS:OK")

    fun close() {
        try { socket?.close() } catch (_: IOException) {}
        socket = null
        readThreadRunning = false
        _status.postValue("Rozłączony")
        synchronized(lineBuffer) { lineBuffer.clear() }
        lastSentCommand = null
    }
}

