package com.example.smartalarmbt

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.smartalarmbt.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val vm: MainViewModel by viewModels()

    private val addAlarmLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {

            val hour = result.data!!.getIntExtra("hour", 7)
            val minute = result.data!!.getIntExtra("minute", 0)
            val mission = MissionType.valueOf(
                result.data!!.getStringExtra("mission") ?: MissionType.QUIZ.name
            )

            vm.addAlarm(this, hour, minute, mission)
        }
    }

    private val editAlarmLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->

        if (result.resultCode == 999 && result.data != null) {
            val id = result.data!!.getIntExtra("delete_id", -1)
            vm.deleteAlarmById(this, id)
            return@registerForActivityResult
        }

        if (result.resultCode == RESULT_OK && result.data != null) {
            val id = result.data!!.getIntExtra("id", -1)
            val hour = result.data!!.getIntExtra("hour", 7)
            val minute = result.data!!.getIntExtra("minute", 0)
            val mission = MissionType.valueOf(
                result.data!!.getStringExtra("mission") ?: MissionType.QUIZ.name
            )

            vm.updateAlarm(this, id, hour, minute, mission)
        }
    }

    private val btPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        val granted = perms.values.all { it == true }

        if (granted) {
            BluetoothManager.startAutoReconnect(this)
            connectBt()
        } else {
            Toast.makeText(this, "Brak uprawnień Bluetooth", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ensureBtPermissionAndConnect()
        ensureStepPermission()

        setupRecycler()
        setupObservers()
        setupListeners()
    }

    private fun ensureStepPermission() {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACTIVITY_RECOGNITION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACTIVITY_RECOGNITION),
                201
            )
        }
    }

    private fun setupRecycler() {
        val adapter = AlarmAdapter(
            onEdit = { alarm ->
                val intent = Intent(this, AddAlarmActivity::class.java).apply {
                    putExtra("edit_mode", true)
                    putExtra("id", alarm.id)
                    putExtra("hour", alarm.hour)
                    putExtra("minute", alarm.minute)
                    putExtra("mission", alarm.missionType.name)
                }
                editAlarmLauncher.launch(intent)
            },

            onToggleActive = { alarm, active ->
                vm.updateAlarmActive(this, alarm.id, active)
            }
        )

        binding.rvAlarms.layoutManager = LinearLayoutManager(this)
        binding.rvAlarms.adapter = adapter

        vm.alarms.observe(this) { list ->
            adapter.submitList(list)
        }
    }

    private fun setupObservers() {
        BluetoothManager.status.observe(this) { status ->
            binding.tvBtStatus.text = "BT: $status"

            if (status.startsWith("Połączono")) {
                BluetoothManager.syncTimeWithMcu(this)
            }
        }

        BluetoothManager.lastMessage.observe(this) { msg ->
            binding.tvLastStatus.text = "Status budzika: $msg"
        }
    }

    private fun setupListeners() {

        binding.fabAdd.setOnClickListener {
            val intent = Intent(this, AddAlarmActivity::class.java)
            addAlarmLauncher.launch(intent)
        }

    }

    private fun ensureBtPermissionAndConnect() {
        val needed = mutableListOf<String>()

        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.BLUETOOTH_CONNECT
            ) != PackageManager.PERMISSION_GRANTED
        ) needed.add(Manifest.permission.BLUETOOTH_CONNECT)

        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.BLUETOOTH_SCAN
            ) != PackageManager.PERMISSION_GRANTED
        ) needed.add(Manifest.permission.BLUETOOTH_SCAN)

        if (needed.isNotEmpty()) {
            btPermissionLauncher.launch(needed.toTypedArray())
        } else {
            BluetoothManager.startAutoReconnect(this)
            connectBt()
        }
    }

    private fun connectBt() {
        BluetoothManager.connect(this)
    }
}
