package com.example.smartalarmbt

import android.Manifest
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.example.smartalarmbt.databinding.ActivityMissionBinding
import kotlin.math.sqrt

class MissionActivity : AppCompatActivity(), SensorEventListener {

    private lateinit var binding: ActivityMissionBinding
    private var missionType: MissionType = MissionType.QUIZ
    private var missionFinished = false
    private var alarmId: Int = -1

    // ----- QUIZ DATA -----
    data class Question(val text: String, val answers: List<String>, val correct: Int)

    private val questionsPool = listOf(
        Question("Ile to 7 * 8?", listOf("54", "56", "64", "48"), 1),
        Question("Pierwiastek z 81 to:", listOf("7", "8", "9", "10"), 2),
        Question("Który z tych jest liczbą pierwszą?", listOf("15", "21", "17", "33"), 2),
        Question("Ile to 12 + 13?", listOf("25", "24", "26", "23"), 0),
        Question("Ile to 45 / 5?", listOf("9", "7", "8", "10"), 0)
    )

    private var currentQuestions: List<Question> = emptyList()
    private var currentQuestionIndex = 0
    private val quizQuestionsToSolve = 3

    // ----- SHAKE -----
    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null

    private var lastAccel = SensorManager.GRAVITY_EARTH
    private var accelCurrent = SensorManager.GRAVITY_EARTH
    private var accelFiltered = 0f
    private var shakeCount = 0
    private val shakesNeeded = 30
    private var lastShakeTime = 0L
    private val shakeCooldown = 200L

    // ----- STEPS -----
    private var stepSensor: Sensor? = null
    private var baseStepCount: Float? = null
    private var stepsDone = 0
    private val stepsNeeded = 20

    private fun enableImmersiveMode() {
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                    View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enableImmersiveMode()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMissionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // blokada przycisku WSTECZ
        onBackPressedDispatcher.addCallback(this) {}

        try { startLockTask() } catch (_: Exception) {}

        enableImmersiveMode()

        // odczytaj alarmId i spróbuj pobrać typ misji możliwie najbezpieczniej
        alarmId = intent.getIntExtra("alarm_id", -1)

        // najpierw z intentu
        var missionString: String? = intent.getStringExtra("mission")
            ?: intent.getStringExtra("mission_type")

        // jeśli nie ma w intencie, spróbuj pobrać z AlarmRepository (jeśli dostępne)
        if (missionString.isNullOrBlank() && alarmId != -1) {
            try {
                val alarmObj = AlarmRepository.findAlarmById(alarmId)
                if (alarmObj != null) {
                    // próbujemy bezpiecznie odczytać pole mission/type przez reflection (jeśli istnieje)
                    missionString = try {
                        val f = alarmObj.javaClass.getDeclaredField("mission")
                        f.isAccessible = true
                        f.get(alarmObj) as? String
                    } catch (_: NoSuchFieldException) {
                        try {
                            val f2 = alarmObj.javaClass.getDeclaredField("type")
                            f2.isAccessible = true
                            f2.get(alarmObj) as? String
                        } catch (_: Exception) {
                            null
                        }
                    }
                }
            } catch (ex: Exception) {
                Log.w("MissionActivity", "Nie udało się odczytać misji z alarmu: ${ex.message}")
            }
        }

        // zmapuj do enum (bez crasha)
        missionType = try {
            if (!missionString.isNullOrBlank()) MissionType.valueOf(missionString) else MissionType.QUIZ
        } catch (ex: Exception) {
            Log.w("MissionActivity", "Nieprawidłowy missionString='$missionString' -> fallback QUIZ")
            MissionType.QUIZ
        }

        Log.d("MissionActivity", "Start misji: $missionType dla alarmu $alarmId")

        // powiadamiamy MCU że alarm startuje
        try { BluetoothManager.notifyAlarmStarted(this) } catch (_: Exception) {}

        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        stepSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)

        when (missionType) {
            MissionType.QUIZ -> setupQuiz()
            MissionType.SHAKE -> setupShake()
            MissionType.STEPS -> setupSteps()
            MissionType.SNAKE -> setupSnake()
        }
    }

    // ---------------------------------------------------------
    // QUIZ
    // ---------------------------------------------------------
    private fun setupQuiz() {
        showOnly(binding.layoutQuiz)

        currentQuestions = questionsPool.shuffled().take(quizQuestionsToSolve)
        currentQuestionIndex = 0
        showQuestion()

        binding.btnNextQuestion.setOnClickListener {
            val selectedId = binding.rgAnswers.checkedRadioButtonId
            if (selectedId == -1) {
                Toast.makeText(this, "Wybierz odpowiedź!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val chosen = when (selectedId) {
                binding.rbAns1.id -> 0
                binding.rbAns2.id -> 1
                binding.rbAns3.id -> 2
                else -> 3
            }

            if (chosen == currentQuestions[currentQuestionIndex].correct) {
                currentQuestionIndex++
                if (currentQuestionIndex >= currentQuestions.size) missionCompleted()
                else showQuestion()
            } else {
                Toast.makeText(this, "Źle! Spróbuj ponownie", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showQuestion() {
        val q = currentQuestions[currentQuestionIndex]
        binding.tvQuestion.text = q.text
        binding.rbAns1.text = q.answers[0]
        binding.rbAns2.text = q.answers[1]
        binding.rbAns3.text = q.answers[2]
        binding.rbAns4.text = q.answers[3]
        binding.rgAnswers.clearCheck()
    }

    // ---------------------------------------------------------
    // SHAKE
    // ---------------------------------------------------------
    private fun setupShake() {
        showOnly(binding.layoutShake)

        binding.tvMissionTitle.text = "Misja: Potrząśnij telefonem"
        binding.tvMissionDesc.text = "Potrząśnij $shakesNeeded razy."
    }

    // ---------------------------------------------------------
    // STEPS
    // ---------------------------------------------------------
    private fun setupSteps() {
        showOnly(binding.layoutSteps)

        binding.tvMissionTitle.text = "Misja: Kroki"
        binding.tvMissionDesc.text = "Zrób $stepsNeeded kroków."

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACTIVITY_RECOGNITION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACTIVITY_RECOGNITION),
                100
            )
        }
    }

    // ---------------------------------------------------------
    // SNAKE
    // ---------------------------------------------------------
    private fun setupSnake() {
        // pokazujemy widok snakeView (jest w XML)
        showOnly(binding.snakeView)

        binding.tvMissionTitle.text = "Misja: Snake"
        binding.tvMissionDesc.text = "Zdobądź 10 punktów!"

        // defensywne ustawienia + callback
        try {
            binding.snakeView.targetPoints = 5
            binding.snakeView.onMissionComplete = { missionCompleted() }
            binding.snakeView.startGame()
        } catch (ex: Exception) {
            Log.e("MissionActivity", "Błąd podczas uruchamiania SnakeView: ${ex.message}")
            Toast.makeText(this, "Błąd uruchomienia misji Snake", Toast.LENGTH_SHORT).show()
            // fallback do quizu, żeby apka nie padła
            showOnly(binding.layoutQuiz)
            missionType = MissionType.QUIZ
            setupQuiz()
        }
    }

    // helper: pokazuje tylko wskazany widok, chowa resztę
    private fun showOnly(viewToShow: View) {
        binding.layoutQuiz.visibility = View.GONE
        binding.layoutShake.visibility = View.GONE
        binding.layoutSteps.visibility = View.GONE
        binding.snakeView.visibility = View.GONE

        viewToShow.visibility = View.VISIBLE
    }

    override fun onResume() {
        super.onResume()
        try {
            when (missionType) {
                MissionType.SHAKE ->
                    accelerometer?.also { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }

                MissionType.STEPS ->
                    stepSensor?.also { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }

                else -> {}
            }
        } catch (ex: Exception) {
            Log.w("MissionActivity", "registerListener failed: ${ex.message}")
        }
    }

    override fun onPause() {
        super.onPause()
        try {
            sensorManager.unregisterListener(this)
        } catch (_: Exception) {}
    }

    override fun onSensorChanged(e: SensorEvent?) {
        e ?: return

        when (e.sensor.type) {
            Sensor.TYPE_ACCELEROMETER -> processShake(e)
            Sensor.TYPE_STEP_COUNTER -> processSteps(e)
        }
    }

    private fun processShake(e: SensorEvent) {
        val x = e.values.getOrNull(0) ?: 0f
        val y = e.values.getOrNull(1) ?: 0f
        val z = e.values.getOrNull(2) ?: 0f

        accelCurrent = sqrt(x * x + y * y + z * z)
        val delta = accelCurrent - lastAccel
        lastAccel = accelCurrent

        accelFiltered = accelFiltered * 0.9f + delta
        val now = System.currentTimeMillis()

        if (accelFiltered > 15 && now - lastShakeTime > shakeCooldown) {
            lastShakeTime = now
            shakeCount++
            binding.tvShakeProgress.text = "$shakeCount / $shakesNeeded"

            if (shakeCount >= shakesNeeded) missionCompleted()
        }
    }

    private fun processSteps(e: SensorEvent) {
        val total = e.values.getOrNull(0) ?: return
        if (baseStepCount == null) baseStepCount = total

        stepsDone = (total - (baseStepCount ?: total)).toInt().coerceAtLeast(0)
        binding.tvStepsProgress.text = "$stepsDone / $stepsNeeded"

        if (stepsDone >= stepsNeeded) missionCompleted()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    // ---------------------------------------------------------
    // END OF MISSION
    // ---------------------------------------------------------
    private fun missionCompleted() {
        if (missionFinished) return
        missionFinished = true

        try {
            AlarmRepository.findAlarmById(alarmId)?.let {
                AlarmRepository.updateAlarmActive(this, alarmId, false)
            }
        } catch (ex: Exception) {
            Log.w("MissionActivity", "Alarm repo error: ${ex.message}")
        }

        Toast.makeText(this, "Misja zakończona!", Toast.LENGTH_LONG).show()
        try { BluetoothManager.notifyMissionCompleted(this) } catch (_: Exception) {}

        try { stopLockTask() } catch (_: Exception) {}

        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        try { stopLockTask() } catch (_: Exception) {}
    }
}
