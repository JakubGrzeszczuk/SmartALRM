package com.example.smartalarmbt

import android.app.Activity
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.smartalarmbt.databinding.ActivityAddAlarmBinding

class AddAlarmActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddAlarmBinding
    private var editMode = false
    private var editingId = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddAlarmBinding.inflate(layoutInflater)
        setContentView(binding.root)

        editMode = intent.getBooleanExtra("edit_mode", false)

        if (editMode) {
            editingId = intent.getIntExtra("id", -1)
            val hour = intent.getIntExtra("hour", 7)
            val minute = intent.getIntExtra("minute", 0)
            val mission = intent.getStringExtra("mission") ?: MissionType.QUIZ.name

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                binding.timePicker.hour = hour
                binding.timePicker.minute = minute
            } else {
                binding.timePicker.currentHour = hour
                binding.timePicker.currentMinute = minute
            }

            when (mission) {
                MissionType.SHAKE.name -> binding.rbShake.isChecked = true
                MissionType.STEPS.name -> binding.rbSteps.isChecked = true
                MissionType.SNAKE.name -> binding.rbSnake.isChecked = true
                else -> binding.rbQuiz.isChecked = true
            }

            binding.btnSave.text = "Zapisz"
            binding.btnDelete.visibility = android.view.View.VISIBLE

        } else {
            binding.btnDelete.visibility = android.view.View.GONE
        }

        binding.btnCancel.setOnClickListener {
            setResult(Activity.RESULT_CANCELED)
            finish()
        }

        binding.btnSave.setOnClickListener {
            val (h, m) = getTime()
            val mission = when (binding.rgMission.checkedRadioButtonId) {
                binding.rbShake.id -> MissionType.SHAKE
                binding.rbSteps.id -> MissionType.STEPS
                binding.rbSnake.id -> MissionType.SNAKE
                else -> MissionType.QUIZ
            }

            val data = android.content.Intent().apply {
                if (editMode) putExtra("id", editingId)
                putExtra("hour", h)
                putExtra("minute", m)
                putExtra("mission", mission.name)
            }

            setResult(Activity.RESULT_OK, data)
            finish()
        }

        binding.btnDelete.setOnClickListener {
            val data = android.content.Intent().apply {
                putExtra("delete_id", editingId)
            }
            setResult(999, data)
            finish()
        }
    }

    private fun getTime(): Pair<Int, Int> =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            binding.timePicker.hour to binding.timePicker.minute
        else
            binding.timePicker.currentHour to binding.timePicker.currentMinute
}
