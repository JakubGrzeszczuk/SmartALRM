package com.example.smartalarmbt

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class SnakeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val snakeView = SnakeView(this)
        setContentView(snakeView)

        //Ile pkt trzeba zdobyc
        snakeView.targetPoints = 5

        snakeView.onMissionComplete = {
            try {
                BluetoothManager.sendCommand(this, "MIS:SNAKE_OK")
            } catch (_: Exception) { }

            setResult(RESULT_OK)
            finish()
        }

        snakeView.startGame()
    }
}