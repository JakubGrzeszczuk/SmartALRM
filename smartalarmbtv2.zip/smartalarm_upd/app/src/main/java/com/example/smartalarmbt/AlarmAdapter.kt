package com.example.smartalarmbt

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.smartalarmbt.databinding.ItemAlarmBinding

class AlarmAdapter(
    private val onToggleActive: (Alarm, Boolean) -> Unit,
    private val onEdit: (Alarm) -> Unit
) : ListAdapter<Alarm, AlarmAdapter.AlarmViewHolder>(Diff) {

    object Diff : DiffUtil.ItemCallback<Alarm>() {
        override fun areItemsTheSame(oldItem: Alarm, newItem: Alarm) = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: Alarm, newItem: Alarm) = oldItem == newItem
    }

    inner class AlarmViewHolder(val binding: ItemAlarmBinding)
        : RecyclerView.ViewHolder(binding.root) {

        fun bind(item: Alarm) {

            binding.tvTime.text = String.format("%02d:%02d", item.hour, item.minute)

            binding.tvMission.text = when (item.missionType) {
                MissionType.QUIZ -> "Misja: Quiz"
                MissionType.SHAKE -> "Misja: Potrząśnij"
                MissionType.STEPS -> "Misja: Kroki"
                MissionType.SNAKE -> "Misja: Snake"
                else -> "Misja"
            }

            binding.switchActive.isChecked = item.isActive
            binding.switchActive.setOnCheckedChangeListener { _, checked ->
                onToggleActive(item, checked)
            }

            binding.btnEdit.setOnClickListener {
                onEdit(item)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AlarmViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = ItemAlarmBinding.inflate(inflater, parent, false)
        return AlarmViewHolder(binding)
    }

    override fun onBindViewHolder(holder: AlarmViewHolder, position: Int) {
        holder.bind(getItem(position))
    }
}
