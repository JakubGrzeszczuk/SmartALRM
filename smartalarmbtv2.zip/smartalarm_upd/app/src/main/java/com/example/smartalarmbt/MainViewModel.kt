package com.example.smartalarmbt

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel() {

    val alarms: LiveData<List<Alarm>> = AlarmRepository.getAlarms()

    fun addAlarm(context: Context, hour: Int, minute: Int, mission: MissionType) {
        AlarmRepository.addAlarm(context, hour, minute, mission)
    }

    fun deleteAlarmById(context: Context, id: Int) {
        val alarm = AlarmRepository.findAlarmById(id)
        if (alarm != null) {
            AlarmRepository.removeAlarm(context, alarm)
        }
    }

    fun updateAlarm(context: Context, id: Int, hour: Int, minute: Int, mission: MissionType) {
        AlarmRepository.updateAlarm(context, id, hour, minute, mission)
    }

    fun updateAlarmActive(context: Context, id: Int, active: Boolean) {
        AlarmRepository.updateAlarmActive(context, id, active)
    }
}
